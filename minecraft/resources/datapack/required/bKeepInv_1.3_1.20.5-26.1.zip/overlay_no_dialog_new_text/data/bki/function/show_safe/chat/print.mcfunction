# Prints combined message with options

$tellraw @s $(message_list)

tellraw @s [{\
	"text": "\nAdd entry",\
	"color": "#4CB944",\
	"bold": false,\
    "underlined": true,\
	"click_event": {\
		"action": "suggest_command",\
		"command": "/function bki:show_safe/chat/ref_add {item_id:'minecraft:<item_id>'}"\
	},\
    "hover_event": {\
		"action": "show_text",\
		"value": {\
			"text": ""\
		}\
	}\
},\
{\
    "text":" | ",\
    "color":"dark_purple",\
    "bold": true,\
    "underlined": false,\
},\
{\
	"text": "Reset to default",\
	"color": "#F45B26",\
    "bold": false,\
    "underlined": true,\
	"click_event": {\
		"action": "suggest_command",\
		"command": "/function bki:show_safe/chat/ref_reset"\
	}\
},\
{\
    "text":" | ",\
    "color":"dark_purple",\
    "bold": true,\
    "underlined": false,\
},\
{\
	"text": "Go back",\
	"color": "#F8DE22",\
    "bold": false,\
    "underlined": true,\
	"click_event": {\
		"action": "run_command",\
		"command": "/function bki:settings"\
	}\
},\
{\
	"text": "\nAdd mainhand",\
	"color": "#4CB944",\
	"bold": false,\
    "underlined": true,\
	"click_event": {\
		"action": "suggest_command",\
		"command": "/function bki:show_safe/add_mainhand"\
	},\
    "hover_event": {\
		"action": "show_text",\
		"value": {\
			"text": "Add whatever item you hold in your main hand to safe list"\
		}\
	}\
}\
]

data modify storage bki:bki operation merge value {printed:1b}