# List of items that always remain after death
# Except for items with the nbt tag always_drop:1b, because this tag have higher priority
# The list formatting must always remain as shown in the example
# "minecraft:<item_name>",\
# It should work with moded items, but ¯\_(ツ)_/¯

data modify storage bki:bki safe.list set value [\
    "minecraft:ender_chest",\
    "minecraft:clock",\
    "minecraft:shield",\
    "minecraft:white_bed",\
    "minecraft:red_bed",\
    "minecraft:water_bucket",\
    "minecraft:bucket",\
    "minecraft:torch",\
    "minecraft:crafting_table",\
    "minecraft:oak_boat",\
    "minecraft:birch_boat",\
    "minecraft:spruce_boat",\
    "minecraft:jungle_boat",\
    "minecraft:dark_oak_boat",\
    "minecraft:acacia_boat",\
    "minecraft:mangrove_boat",\
    "minecraft:cherry_boat",\
    "minecraft:bamboo_raft",\
    "minecraft:recovery_compass"\
]
# I don't think not losing items from the list above is overpowered but just nice to have
