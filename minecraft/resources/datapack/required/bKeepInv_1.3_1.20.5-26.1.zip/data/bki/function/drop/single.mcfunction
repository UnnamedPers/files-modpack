# Drop and clear the item with random chance, which depends on #items_dropped value (see load or reset function)

execute if predicate {\
	"condition": "minecraft:random_chance",\
	"chance": {\
		"type": "minecraft:score",\
		"target": {\
			"type": "minecraft:fixed",\
			"name": "#items_dropped"\
		},\
		"score": "levels",\
		"scale": 0.01\
	}} run function bki:drop/item with storage bki:bki drop