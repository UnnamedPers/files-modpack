# Add whatever item player hold in main hand to safe list

data modify storage bki:bki safe.list append from entity @s SelectedItem.id
function bki:show_safe/chat/init
# dialog clear @s
function bki:show_safe/dialog/init