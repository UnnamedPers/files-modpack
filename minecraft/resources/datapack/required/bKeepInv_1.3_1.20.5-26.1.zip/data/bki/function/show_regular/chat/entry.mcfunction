# Constructs entry for one item
$data modify storage bki:bki operation.message_list prepend value {\
	"text": "\n    $(index). $(name)",\
	"color": "#924f18",\
	"bold": false,\
	"hover_event": {\
		"action": "show_item",\
		"id": "$(name)"\
	},\
}