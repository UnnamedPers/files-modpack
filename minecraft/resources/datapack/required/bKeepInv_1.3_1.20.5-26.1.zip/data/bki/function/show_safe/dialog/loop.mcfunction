# Prepare entry for every item
# Works from the back and prepends to list

# Get last item
data modify storage bki:bki operation.name set from storage bki:bki safe.list_copy[-1]
# Get the index
execute store result storage bki:bki operation.index int 1 run scoreboard players get #index levels
# Construct entry for one item
function bki:show_safe/dialog/entry with storage bki:bki operation
# Remove last
data remove storage bki:bki safe.list_copy[-1]
# Count down
scoreboard players remove #index levels 1
# If not empty run agian
execute if data storage bki:bki safe.list_copy[0] run function bki:show_safe/dialog/loop