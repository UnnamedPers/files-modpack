# Constructs entry for one item
$data modify storage bki:bki operation.message_list prepend value {\
			"type": "minecraft:item",\
			"item": {\
				"id": "$(name)"\
			},\
			"description": {\
				"text": "$(index). $(name)",\
				"color": "#B99D87",\
			}\
		}