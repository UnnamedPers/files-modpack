# Constructs entry for one item
$data modify storage bki:bki operation.message_list prepend value {\
	"text": "\n    $(index). $(name)",\
	"color": "#924f18",\
	"bold": false,\
	"click_event": {\
		"action": "suggest_command",\
		"command": "/function bki:show_safe/chat/ref_remove {index:'$(index)'}"},\
	"hover_event": {\
		"action": "show_item",\
		"id": "$(name)"\
	},\
}