# Show in game settings
# Prioritizes dialogs but also prints in chat
function bki:show_regular/dialog/init

tellraw @s [{"text":"\nSettings for ","bold":false,"color":"#F45B26"},{"text":"Better Keep Inventory","bold":true,"underlined":true,"color":"#D12052"},{"text":" datapack\n==========================================\n","bold":false,"color":"#F45B26"},\
    {"bold":false,"text":"See them in dialog menu","underlined":true,"color":"#d748d5","click_event":{"action":"run_command","command":"/trigger check_keep_inventory"}},\
    {"bold":false,"text":"\n\n1. XP kept by player (in %)","color":"#F8DE22","hover_event":{"action":"show_text","value":"Default: 0%"}},\
    {"text":"\n    Currently: ","bold":false,"color":"#03AED2"},{"bold":false,"score": {"objective": "levels","name": "#xp_left"}},{"text":" %","bold":false,"color":"#03AED2"},\
    {"bold":false,"text":"\n2. Percentage of lost xp that is dropped (in %)","color":"#F8DE22","hover_event":{"action":"show_text","value":"Default: 50%"}},\
    {"text":"\n    Currently: ","bold":false,"color":"#03AED2"},{"bold":false,"score": {"objective": "levels","name": "#xp_dropped"}},{"text":" %","bold":false,"color":"#03AED2"},\
    {"bold":false,"text":"\n3. Percentage of items dropped (in %)","color":"#F8DE22","hover_event":{"action":"show_text","value":"Default: 100%\nUtleast 1 item is dropped, unless set to 0\nIf item has count 1 this value becomes the base for the random chance of it being dropped."}},\
    {"text":"\n    Currently: ","bold":false,"color":"#03AED2"},{"bold":false,"score": {"objective": "levels","name": "#items_dropped"}},{"text":" %","bold":false,"color":"#03AED2"},\
    {"bold":false,"text":"\n4. Item and xp lifetime (in minutes)","color":"#F8DE22","hover_event":{"action":"show_text","value":"Default: 5 min\nHow long before they despawn.\nInfinite if set to more than 32 min"}},\
    {"text":"\n    Currently: ","bold":false,"color":"#03AED2"},{"bold":false,"score": {"objective": "levels","name": "#lifetime"}},{"text":" min","bold":false,"color":"#03AED2"},\
    {"bold":false,"text":"\n5. Show players settings for this datapack on theirs first join (1 - true, 0 - false)","color":"#F8DE22","hover_event":{"action":"show_text","value":"Default: True"}},\
    {"text":"\n    Currently: ","bold":false,"color":"#03AED2"},{"bold":false,"score": {"objective": "levels","name": "#show_fjoin"}},\
    {"bold":false,"text":"\n6. Safe items list (they don't drop upon death)","color":"#F8DE22"}]


function bki:show_regular/chat/init

tellraw @s {\
	"text": "\nShow in dialog",\
	"color": "#595455",\
    "bold": false,\
    "underlined": true,\
	"click_event": {\
		"action": "run_command",\
		"command": "/trigger check_keep_inventory"\
	}\
}

tellraw @s {\
	"text": "Change settings",\
	"color": "white",\
    "underlined":true,\
	"click_event": {\
		"action": "run_command",\
		"command": "function bki:settings"\
	},\
	"hover_event": {\
		"action": "show_text",\
		"value": {\
			"text": "Need permissions"\
		}\
	}\
}