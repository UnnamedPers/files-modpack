# Adds and refreshes
$data modify storage bki:bki safe.list append value "$(item_id)"
function bki:show_safe/dialog/init