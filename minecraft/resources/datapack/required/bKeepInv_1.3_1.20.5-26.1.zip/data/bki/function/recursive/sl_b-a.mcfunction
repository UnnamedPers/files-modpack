# Subtract list after from list before

# Get the last element of the list
data modify storage bki:bki operation.tmp set from storage bki:bki items.after_copy[-1]
# Remove one item from list after from list before
function bki:recursive/ro_b-a with storage bki:bki operation
# Remove used element
data remove storage bki:bki items.after_copy[-1]

# repeat till the list is empty
execute if data storage bki:bki items.after_copy[0] run function bki:recursive/sl_b-a