# Remove one item from list after from list before

$data remove storage bki:bki items.before[$(tmp)]