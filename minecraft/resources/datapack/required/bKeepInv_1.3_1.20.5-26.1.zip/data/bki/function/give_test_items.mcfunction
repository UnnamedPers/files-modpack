# Test items

# Not drop
give @s ender_chest
give @s shield
give @s crafting_table

# drop
give @s dirt
give @s oak_door

# tag
give @s water_bucket[custom_data={always_drop:1b}]
give @s bucket[custom_data={always_drop:1b}]

# tag
give @s acacia_fence[custom_data={never_drop:1b}]
give @s acacia_fence[custom_data={never_drop:1b}]

give @s golden_axe[enchantments={vanishing_curse:1}]

xp set @s 10 levels