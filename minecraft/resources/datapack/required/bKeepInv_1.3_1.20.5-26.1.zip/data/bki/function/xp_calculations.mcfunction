# Preparing data for calculation
execute store result score #level levels store result score #xp levels store result score #level_squared levels run xp query @s levels
execute store result score #points levels run xp query @s points
# Calculations based on formulas given by the wiki
# Total experience =
#   level^2 + 6 × level (at levels 0–16)
#   2.5 × level^2 – 40.5 × level + 360 (at levels 17–31)
#   4.5 × level^2 – 162.5 × level + 2220 (at levels 32+)

# First part of equation
scoreboard players operation #level_squared levels *= #level_squared levels
execute if score #level levels matches 17..31 run scoreboard players operation #level_squared levels *= #5 levels
execute if score #level levels matches 32.. run scoreboard players operation #level_squared levels *= #9 levels

# Second part of equation
execute if score #level levels matches 1..16 run scoreboard players operation #xp levels *= #6 levels
execute if score #level levels matches 17..31 run scoreboard players operation #xp levels *= #-81 levels
execute if score #level levels matches 32.. run scoreboard players operation #xp levels *= #-325 levels

execute if score #level levels matches 17.. run scoreboard players operation #level_squared levels /= #2 levels
execute if score #level levels matches 17.. run scoreboard players operation #xp levels /= #2 levels

# Last part of equation
execute if score #level levels matches 17..31 run scoreboard players add #xp levels 360
execute if score #level levels matches 32.. run scoreboard players add #xp levels 2220
scoreboard players operation #xp levels += #level_squared levels
scoreboard players operation #xp levels += #points levels

# Now total experience is under #xp value

# What is left for the player
scoreboard players operation #xp_player levels = #xp levels
scoreboard players operation #xp_player levels *= #xp_left levels
scoreboard players operation #xp_player levels /= #100 levels

# Xp to drop
scoreboard players operation #xp_drop levels = #xp levels
scoreboard players operation #xp_drop levels -= #xp_player levels
scoreboard players operation #xp_drop levels *= #xp_dropped levels
scoreboard players operation #xp_drop levels /= #100 levels

# For values #xp_left and #xp_dropped ckeck load or reset function


# Values for macro
execute store result storage bki:bki drop.xp_player int 1 run scoreboard players get #xp_player levels
execute store result storage bki:bki drop.xp_drop int 1 run scoreboard players get #xp_drop levels
execute store result storage bki:bki drop.age int 1 run scoreboard players get #age levels

# Add some random movement to mimic the orginal
execute store result storage bki:bki drop.x_motion double 0.01 run random value -20..20
execute store result storage bki:bki drop.z_motion double 0.01 run random value -20..20

# Reset player xp
xp set @s 0 levels
xp set @s 0 points

# Summon xp orb at place of death and give player xp that player is left with after death
function bki:drop/xp with storage bki:bki drop