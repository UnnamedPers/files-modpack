# Let them trigger again
scoreboard players reset @s check_keep_inventory
scoreboard players enable @s check_keep_inventory

# Show settings
function bki:show_regular/settings