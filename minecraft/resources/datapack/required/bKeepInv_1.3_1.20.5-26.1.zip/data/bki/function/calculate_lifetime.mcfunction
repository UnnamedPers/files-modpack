# Calculate lifetime for items and xp

scoreboard players operation #lifetime_ticks levels = #lifetime levels
# Minutes to ticks
scoreboard players operation #lifetime_ticks levels *= #1200 levels
scoreboard players set #age levels 6000
scoreboard players operation #age levels -= #lifetime_ticks levels
# Formula
# 6000 despawn = x + 1200 * min
# x = 6000 - 1200 * min

# Safeguard for value overflow and feedback to see it in settings
execute if score #age levels matches ..-32768 run scoreboard players set #lifetime levels 9999999
execute if score #age levels matches ..-32768 run scoreboard players set #age levels -32768