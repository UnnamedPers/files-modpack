$data modify storage bki:bki operation.message_list prepend value {\
	"type": "minecraft:plain_message",\
	"contents": [\
        {\
		    "text": "XP kept by player \n=======================================",\
		    "color": "#F8DE22",\
		    "bold": true\
	    },\
		{\
			"text": "\nXP that player is left with after death (in %)    Default: 0%",\
			"color": "#03AED2",\
		    "bold": false\
		},\
		{\
			"text":"\nCurrently: ",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
			"text":"$(xp_left)",\
			"bold":false,\
			"color":"#F8DE22"\
		},\
		{\
			"text":" %",\
			"bold":false,\
			"color":"#F45B26"\
		},\
        {\
		    "text": "\n\nLost xp that is dropped\n=======================================",\
		    "color": "#F8DE22",\
		    "bold": true\
	    },\
        {\
			"text": "\nPercentage of lost xp that remains and can be pick up at the place of death (in %)    Default: 50%",\
			"color": "#03AED2",\
		    "bold": false\
		},\
		{\
			"text":"\nCurrently: ",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
			"text":"$(xp_dropped)",\
			"bold":false,\
			"color":"#F8DE22"\
		},\
		{\
			"text":" %",\
			"bold":false,\
			"color":"#F45B26"\
		},\
        {\
		    "text": "\n\nItems dropped\n=======================================",\
		    "color": "#F8DE22",\
		    "bold": true\
	    },\
        {\
			"text": "\nPercentage of items that drops upon player death, rounded down.\nUtleast 1 item is dropped, unless set to 0. If item has count 1 this value becomes the base for the random chance of it being dropped.    Default: 100%",\
			"color": "#03AED2",\
			"bold": false\
		},\
		{\
			"text":"\nCurrently: ",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
			"text":"$(items_dropped)",\
			"bold":false,\
			"color":"#F8DE22"\
		},\
		{\
			"text":" %",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
		    "text": "\n\nItem and xp lifetime\n=======================================",\
		    "color": "#F8DE22",\
		    "bold": true\
	    },\
        {\
			"text": "\nHow long before they despawn.    Default: 5 min\nInfinite if set to more than 32 min",\
			"color": "#03AED2",\
		    "bold": false\
		},\
		{\
			"text":"\nCurrently: ",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
			"text":"$(lifetime)",\
			"bold":false,\
			"color":"#F8DE22"\
		},\
		{\
			"text":" min",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
		    "text": "\n\nShow on first join\n=======================================",\
		    "color": "#F8DE22",\
		    "bold": true\
	    },\
        {\
			"text": "\nShow players settings for this datapack on theirs first join    Default: True",\
			"color": "#03AED2",\
		    "bold": false\
		},\
		{\
			"text":"\nCurrently: ",\
			"bold":false,\
			"color":"#F45B26"\
		},\
		{\
			"text":"$(show_fjoin)",\
			"bold":false,\
			"color":"#F8DE22"\
		}\
	],\
	"width": 350\
}