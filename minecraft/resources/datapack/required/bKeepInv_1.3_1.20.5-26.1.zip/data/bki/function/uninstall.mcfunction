scoreboard objectives remove levels
scoreboard objectives remove check_keep_inventory
data remove storage bki:bki drop
data remove storage bki:bki operation
data remove storage bki:bki items
data remove storage bki:bki safe

say Better keep inventory datapack uninstalled