schedule function bki:show_regular/trigger_check 5s

execute as @a if score @s check_keep_inventory matches 1.. run function bki:show_regular/trigger_player