# Checking the gamerule
execute store result score #disabled_keepInv levels run gamerule keep_inventory
execute if score #disabled_keepInv levels matches 0 run say Gamerule keepInventory was previously set to false, but was set to true for Better Keep Inventory datapack to work!
execute if score #disabled_keepInv levels matches 0 run gamerule keep_inventory true