# Prints combined dialog
$dialog show @s {\
	"type": "minecraft:multi_action",\
	"title": {\
		"text": "Safe list",\
		"color": "#F8DE22",\
		"bold": true\
	},\
	"body": $(message_list),\
	"inputs": [\
		{\
			"type": "minecraft:text",\
			"key": "item_id",\
			"width": 145,\
			"label": {\
				"text": "Add entry: minecraft:<item_id>"\
			},\
			"initial": "minecraft:",\
			"max_length": 50\
		}\
	],\
	"can_close_with_escape": true,\
	"pause": false,\
	"after_action": "none",\
	"exit_action": {\
		"label": {\
			"text": "Back"\
		},\
		"action": {\
			"type": "minecraft:show_dialog",\
			"dialog": "bki:settings"\
		}\
	},\
	"columns": 3,\
	"actions": [\
		{\
			"label": {\
				"text": "Add entry",\
				"color": "#45c73c",\
			},\
            "width": 100,\
			"action": {\
				"type": "minecraft:dynamic/run_command",\
				"template": "function bki:show_safe/dialog/ref_add {item_id:'\u0024(item_id)'}"\
			},\
			"tooltip": {\
				"text": "Add entry with name from input field"\
			}\
		},\
		{\
			"label": {\
				"text": "Reset to default",\
				"color": "#F45B26"\
			},\
            "width": 100,\
			"action": {\
				"type": "minecraft:run_command",\
				"command": "function bki:show_safe/dialog/ref_reset"\
			}\
		},\
		{\
			"label": {\
				"text": "Remove last",\
				"color": "#F45B26",\
			},\
            "width": 100,\
			"action": {\
				"type": "minecraft:run_command",\
				"command": "function bki:show_safe/dialog/ref_remove {index:'-1'}"\
			}\
		},\
		{\
			"label": {\
				"text": "Add mainhand",\
				"color": "#45c73c",\
			},\
            "width": 150,\
			"action": {\
				"type": "minecraft:run_command",\
				"command": "function bki:show_safe/add_mainhand"\
			},\
			"tooltip": {\
				"text": "Add whatever item you hold in your main hand to safe list"\
			}\
		}\
	]\
}



# {
# 	"type": "minecraft:multi_action",
# 	"title": {
# 		"text": "Safe list",
# 		"color": "#00d6b3",
# 		"bold": true
# 	},
# 	"body": [
# 		{
# 			"type": "minecraft:plain_message",
# 			"contents": [
# 				{
# 					"text": "List of items that always remain after death\n=======================================",
# 					"color": "#00d6b3"
# 				},
# 				{
# 					"text": "\nExcept for items with the nbt tag always_drop:1b, because this tag have higher priority",
# 					"color": "gold"
# 				},
# 				{
# 					"text": "\nYou can delete an entry by clicking it",
# 					"color": "#892f18",
# 					"bold": true
# 				},
# 				{
# 					"text": "\nIt should work with moded items, but ¯\\_(ツ)_/¯",
# 					"color": "#666251"
# 				}
# 			],
# 			"width": 300
# 		},
# 		{
# 			"type": "minecraft:item",
# 			"item": {
# 				"id": "<item_name>"
# 			},
# 			"description": {
# 				"text": "$(index). <item_name>",
# 				"click_event": {
# 					"action": "run_command",
# 					"command": "data remove storage bki:bki safe.list[$(index)]"
# 				},
# 				"hover_event": {
# 					"action": "show_text",
# 					"value": {
# 						"text": "Click to remove"
# 					}
# 				}
# 			}
# 		}
# 	],
# 	"inputs": [
# 		{
# 			"type": "minecraft:text",
# 			"key": "item_id",
# 			"width": 145,
# 			"label": {
# 				"text": "Add entry: minecraft:<item_id>"
# 			},
# 			"initial": "minecraft:",
# 			"max_length": 50
# 		}
# 	],
# 	"can_close_with_escape": true,
# 	"pause": false,
# 	"after_action": "none",
# 	"exit_action": {
# 		"label": {
# 			"text": "Back"
# 		},
# 		"action": {
# 			"type": "minecraft:show_dialog",
# 			"dialog": "bki:settings"
# 		}
# 	},
# 	"columns": 3,
# 	"actions": [
# 		{
# 			"label": {
# 				"text": "Add entry",
# 				"color": "dark_green"
# 			},
# 			"action": {
# 				"type": "minecraft:dynamic/run_command",
# 				"template": "data modify storage bki:bki safe.list append value \"minecraft:$(item_id)\""
# 			}
# 		},
# 		{
# 			"label": {
# 				"text": "Refresh the list",
# 				"color": "dark_green"
# 			},
# 			"action": {
# 				"type": "minecraft:run_command",
# 				"command": "function bki:dialog_not_dropped_list"
# 			}
# 		},
# 		{
# 			"label": {
# 				"text": "Reset to default",
# 				"color": "#8a1420"
# 			},
# 			"action": {
# 				"type": "minecraft:run_command",
# 				"command": "function bki:reset_items"
# 			}
# 		}
# 	]
# }