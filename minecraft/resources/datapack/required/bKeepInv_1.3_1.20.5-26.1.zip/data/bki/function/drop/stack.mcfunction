# Drop only part of the stack

# Math
scoreboard players operation #item_count levels *= #items_dropped levels
scoreboard players operation #item_count levels /= #100 levels

# If the number of plural items (means more than 1 item in the stack) to be dropped were to be 0, it becomes 1 instead, unless #items_dropped is also 0
execute unless score #items_dropped levels matches 0 if score #item_count levels matches 0 run scoreboard players set #item_count levels 1

# Save this operation
execute store result storage bki:bki drop.item.count int 1 run scoreboard players get #item_count levels

# Drop and take the item away from the inventory
function bki:drop/item with storage bki:bki drop