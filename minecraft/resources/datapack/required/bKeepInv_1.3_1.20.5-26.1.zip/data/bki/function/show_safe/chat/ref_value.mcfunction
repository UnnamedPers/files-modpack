# Refreshes and changes given value
$scoreboard players set #$(setting) levels $(value)
function bki:calculate_lifetime
function bki:settings