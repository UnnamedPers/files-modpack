# Refreshes and changes given value
$scoreboard players set #$(setting) levels $(value)
function bki:calculate_lifetime
dialog show @s bki:settings