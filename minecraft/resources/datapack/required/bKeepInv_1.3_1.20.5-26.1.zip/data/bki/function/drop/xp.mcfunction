# Summon xp orb at the place of death with value specified
$summon experience_orb ~ ~ ~ {Age:$(age)s,Value:$(xp_drop),Motion:[$(x_motion)d,0.3d,$(z_motion)d]}

# give player xp that player is left with after death
$xp add @s $(xp_player) points

data remove storage bki:bki drop.xp_drop
data remove storage bki:bki drop.xp_player