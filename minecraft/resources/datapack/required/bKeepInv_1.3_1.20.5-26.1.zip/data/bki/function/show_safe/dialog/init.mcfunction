# Initialising dialog construction of safe list

# Getting the index for numbered list
execute store result score #index levels run data get storage bki:bki safe.list
# Remove 1, because we have to count like programmer, from 0
scoreboard players remove #index levels 1
# Clear last message
data modify storage bki:bki operation.message_list set value []

# Make copy of list after as it will be deleted during the recursion and is necessary later
data modify storage bki:bki safe.list_copy set from storage bki:bki safe.list

# Always print something
execute unless data storage bki:bki safe.list[0] run data modify storage bki:bki operation.message_list append value {\
			"type": "minecraft:plain_message",\
			"contents": [\
				{\
					"text": "List is currently empty.",\
					"color":"#D12052"\
				}\
			],\
			"width": 300\
		}

# Prepare entry for every item
execute if data storage bki:bki safe.list[0] run function bki:show_safe/dialog/loop with storage bki:bki operation

# Add heading to dialog
data modify storage bki:bki operation.message_list prepend value {\
			"type": "minecraft:plain_message",\
			"contents": [\
				{\
					"text": "List of items that always remain after death\n=======================================",\
					"color": "#F8DE22"\
				},\
				{\
					"text": "\nExcept for items with the nbt tag always_drop:1b, because this tag have higher priority",\
					"color": "#03AED2"\
				},\
				{\
					"text": "\nYou can delete an entry by clicking it",\
					"color": "#F45B26",\
					"bold": false\
				},\
				{\
					"text": "\nIt should work with moded items, but ¯\\_(ツ)_/¯",\
					"color": "#8A856E"\
				}\
			],\
			"width": 300\
		}

# Instruction what to do if list doesn't work
data modify storage bki:bki operation.message_list append value {\
			"type": "minecraft:plain_message",\
			"contents": [\
				{\
					"text": "If list of items above is not refreshing that means an item inside it is spelled wrong. If you just added new entry use option below to remove the last one from the list.",\
					"color": "#F45B26"\
				}\
			],\
			"width": 300\
		}

# Prints combined dialog
function bki:show_safe/dialog/print with storage bki:bki operation