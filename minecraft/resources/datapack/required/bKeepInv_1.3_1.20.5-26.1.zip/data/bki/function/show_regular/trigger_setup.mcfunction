# Function for advancement
scoreboard players enable @s check_keep_inventory

# Whether to show them settings on their first join
execute if score #show_fjoin levels matches 1 run scoreboard players set @s check_keep_inventory 1