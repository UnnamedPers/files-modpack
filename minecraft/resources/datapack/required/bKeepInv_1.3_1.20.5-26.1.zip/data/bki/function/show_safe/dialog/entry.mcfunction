# Constructs entry for one item
$data modify storage bki:bki operation.message_list prepend value {\
			"type": "minecraft:item",\
			"item": {\
				"id": "$(name)"\
			},\
			"description": {\
				"text": "$(index). $(name)",\
				"color": "#B99D87",\
				"click_event": {\
					"action": "run_command",\
					"command": "function bki:show_safe/dialog/ref_remove {index:'$(index)'}"\
				},\
				"hover_event": {\
					"action": "show_text",\
					"value": {\
						"text": "Click to remove"\
					}\
				}\
			}\
		}