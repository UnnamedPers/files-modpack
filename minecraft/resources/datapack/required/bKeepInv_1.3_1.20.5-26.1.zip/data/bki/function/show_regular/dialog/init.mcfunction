# Initialising dialog construction of safe list

# Getting the index for numbered list
execute store result score #index levels run data get storage bki:bki safe.list
# Remove 1, because we have to count like programmer, from 0
scoreboard players remove #index levels 1
# Clear last message
data modify storage bki:bki operation.message_list set value []

# Make copy of list after as it will be deleted during the recursion and is necessary later
data modify storage bki:bki safe.list_copy set from storage bki:bki safe.list

# Always print something
execute unless data storage bki:bki safe.list[0] run data modify storage bki:bki operation.message_list append value {\
			"type": "minecraft:plain_message",\
			"contents": [\
				{\
					"text": "List is currently empty.",\
					"color":"#D12052"\
				}\
			],\
			"width": 300\
		}

# Prepare entry for every item
execute if data storage bki:bki safe.list[0] run function bki:show_regular/dialog/loop with storage bki:bki operation

# Add heading to dialog
data modify storage bki:bki operation.message_list prepend value {\
			"type": "minecraft:plain_message",\
			"contents": [\
				{\
					"text": "List of items that always remain after death\n=======================================",\
					"color": "#F8DE22",\
					"bold":false\
				},\
			],\
			"width": 300\
		}

execute store result storage bki:bki operation.xp_left int 1 run scoreboard players get #xp_left levels
execute store result storage bki:bki operation.xp_dropped int 1 run scoreboard players get #xp_dropped levels
execute store result storage bki:bki operation.items_dropped int 1 run scoreboard players get #items_dropped levels
execute store result storage bki:bki operation.lifetime int 1 run scoreboard players get #lifetime levels
execute store result storage bki:bki operation.show_fjoin int 1 run scoreboard players get #show_fjoin levels

function bki:show_regular/dialog/values with storage bki:bki operation

# Prints combined dialog
function bki:show_regular/dialog/print with storage bki:bki operation