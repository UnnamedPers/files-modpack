# Resets and refreshes
function bki:reset_safe
function bki:show_safe/chat/init