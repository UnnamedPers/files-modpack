# Items before doing something with them to know what is missing after
data modify storage bki:bki items.before set from entity @s Inventory
execute if data storage bki:bki items.before[0] run data modify storage bki:bki items.before[] merge value {type:"container"}
# Handling equipment slots
data modify storage bki:bki items.before append from entity @s equipment.head
execute unless data storage bki:bki items.before[-1].Slot run data modify storage bki:bki items.before[-1] merge value {type:"armor",Slot:"head"}
data modify storage bki:bki items.before append from entity @s equipment.chest
execute unless data storage bki:bki items.before[-1].Slot run data modify storage bki:bki items.before[-1] merge value {type:"armor",Slot:"chest"}
data modify storage bki:bki items.before append from entity @s equipment.legs
execute unless data storage bki:bki items.before[-1].Slot run data modify storage bki:bki items.before[-1] merge value {type:"armor",Slot:"legs"}
data modify storage bki:bki items.before append from entity @s equipment.feet
execute unless data storage bki:bki items.before[-1].Slot run data modify storage bki:bki items.before[-1] merge value {type:"armor",Slot:"feet"}
data modify storage bki:bki items.before append from entity @s equipment.offhand
execute unless data storage bki:bki items.before[-1].Slot run data modify storage bki:bki items.before[-1] merge value {type:"weapon",Slot:"offhand"}


# Old inventory
execute if data storage bki:bki items.before[{Slot:100b}] run data modify storage bki:bki items.before[{Slot:100b}] merge value {type:"armor",Slot:"feet"}
execute if data storage bki:bki items.before[{Slot:101b}] run data modify storage bki:bki items.before[{Slot:101b}] merge value {type:"armor",Slot:"legs"}
execute if data storage bki:bki items.before[{Slot:102b}] run data modify storage bki:bki items.before[{Slot:102b}] merge value {type:"armor",Slot:"chest"}
execute if data storage bki:bki items.before[{Slot:103b}] run data modify storage bki:bki items.before[{Slot:103b}] merge value {type:"armor",Slot:"head"}
execute if data storage bki:bki items.before[{Slot:-106b}] run data modify storage bki:bki items.before[{Slot:-106b}] merge value {type:"weapon",Slot:"offhand"}