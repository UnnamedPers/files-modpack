# Removes and refreshes
$data remove storage bki:bki safe.list[$(index)]
function bki:show_safe/dialog/init