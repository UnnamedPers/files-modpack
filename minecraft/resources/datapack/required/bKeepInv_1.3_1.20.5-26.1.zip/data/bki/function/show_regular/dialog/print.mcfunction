# Prints combined dialog
$dialog show @s {\
	"type": "minecraft:confirmation",\
	"title": {\
		"text": "Safe list",\
		"color": "#F8DE22",\
		"bold": true\
	},\
	"body": $(message_list),\
	"can_close_with_escape": true,\
	"pause": false,\
	"after_action": "close",\
	"yes": {\
		"label": {\
			"text": "Change settings"\
		},\
		"tooltip": {\
			"text": "Need permissions"\
		},\
		"action": {\
			"type": "minecraft:run_command",\
			"command": "function bki:settings"\
		}\
	},\
	"no": {\
		"label": "Close",\
		"action": {\
			"type": "minecraft:suggest_command",\
			"command": ""\
		}\
	}\
}