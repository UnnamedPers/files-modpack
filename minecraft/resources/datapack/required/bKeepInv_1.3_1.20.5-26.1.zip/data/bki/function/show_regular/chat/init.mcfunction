# Initialising chat construction of safe list

# Getting the index for numbered list
execute store result score #index levels run data get storage bki:bki safe.list
# Remove 1, because we have to count like programmer, from 0
scoreboard players remove #index levels 1
# Clear last message
data modify storage bki:bki operation.message_list set value []

# Always print something
execute unless data storage bki:bki safe.list[0] run tellraw @s {"text":"\n    List is currently empty.","color":"#F45B26"}

# Make copy of list after as it will be deleted during the recursion and is necessary later
data modify storage bki:bki safe.list_copy set from storage bki:bki safe.list

# Prepare entry for every item
execute if data storage bki:bki safe.list[0] run function bki:show_regular/chat/loop with storage bki:bki operation

# Prints combined message with options
function bki:show_regular/chat/print with storage bki:bki operation

# Safecheck if list was shown
execute unless data storage bki:bki operation.printed run tellraw @s [\
    {"text": "\nIt seems you can't see list of items which should appear above. That mean an item inside it is spelled wrong. You should tell your op about it.","color": "#F45B26"}]
# Reset safecheck
data remove storage bki:bki operation.printed