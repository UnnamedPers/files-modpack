# Summon items that were already cleared

# Get the last element of the list
data modify storage bki:bki drop.item set from storage bki:bki items.before[-1]

# Add some random movement to mimic the orginal
execute store result storage bki:bki drop.x_motion double 0.01 run random value -20..20
execute store result storage bki:bki drop.z_motion double 0.01 run random value -20..20

# Unpack the values
data modify storage bki:bki drop.Slot set from storage bki:bki drop.item.Slot
data modify storage bki:bki drop.type set from storage bki:bki drop.item.type
execute store result storage bki:bki drop.age int 1 run scoreboard players get #age levels

# Summon and technically clear singular slot
function bki:drop/item with storage bki:bki drop

# Remove used element
data remove storage bki:bki items.before[-1]
# repeat till the list is empty
execute if data storage bki:bki items.before[0] run function bki:recursive/summon_cleared