# Datapack inspired by and based on KeepSomeInventory by PuckiSilver

# What is it doing?
#   - This datapack allows you to configure which items don't drop upon player death and how much is dropped from the rest.
#       Singular or unstackable items have random chance of dropping based on the same value how much plural items (means more than 1 item in the stack) are dropped.
#   - It let you configure how xp behave after death. By default everything is dropped and 50% can be pick up at the place of death which is far more than vanilla and it's max 7 levels.
#   - You can give players items with custom data always_drop:1b and never_drop:1b which take priority over general list.

# Main purpose of this datapack was to create list of items that do not drop for a SMP
# The datapack I was inspired by, was insufficient, easy to made but hard to use
# So I made my own. Then I added rest of the features that were nice to have

# Priority of items settings
# 1. components:{"minecraft:custom_data":{always_drop:1b}}
#       Example command: /give @s minecraft:ender_chest[minecraft:custom_data={always_drop:1b}] 1
# 2. components:{"minecraft:custom_data":{never_drop:1b}}
#       Works like Bedrock keep_on_death tag, unless the item als have curse of vanishing
# 3. List of items that do not drop.
#       Default list is inside bki:reset function, you can edit it there with text editor and than run the function or try using bki:settings function in game.
# 4. The rest is dropped. By default it is everything, but you can adjust drop percentage in the same way as the list above

# There will be no updates of this datapack unless I will need it myself, but feel free to modify it yourself
# For that I'm leaving comments so future someone will be able to quickly understand what it does


# Setting up the datapack, eventually reset to default values
# Executes unless it was previously done
execute unless data storage bki:bki safe.init run function bki:reset

# test
# function bki:reset


# Checking the gamerule
# Different name in older versions
function bki:check_kinv

# Start checking for trigger
function bki:show_regular/trigger_check