# Subtract list safe from list after

# Get the last element of the list
data modify storage bki:bki operation.tmp set from storage bki:bki safe.list_copy[-1]
# Remove one item from list safe from list after
function bki:recursive/ro_a-safe with storage bki:bki operation
# Remove used element
data remove storage bki:bki safe.list_copy[-1]

# repeat till the list is empty
execute if data storage bki:bki safe.list_copy[0] run function bki:recursive/sl_a-safe