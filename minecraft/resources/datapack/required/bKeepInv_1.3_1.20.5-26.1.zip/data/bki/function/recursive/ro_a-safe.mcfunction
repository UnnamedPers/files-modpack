# Remove one item from list safe from list after

$data remove storage bki:bki items.after[{id:"$(tmp)"}]