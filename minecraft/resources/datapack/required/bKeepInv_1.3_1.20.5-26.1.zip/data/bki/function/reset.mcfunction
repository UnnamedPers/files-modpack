# Constants for calculations
scoreboard objectives add levels dummy
scoreboard players set #2 levels 2
scoreboard players set #5 levels 5
scoreboard players set #6 levels 6
scoreboard players set #9 levels 9
scoreboard players set #-81 levels -81
scoreboard players set #-325 levels -325
scoreboard players set #100 levels 100
scoreboard players set #1200 levels 1200

# Way to signal that function was previously run
data modify storage bki:bki safe merge value {init:1b}

# XP kept by player (in %)
# Percentage of lost xp that is dropped (in %)
# Percentage of items dropped, rounded down.
# Utleast 1 item is dropped, unless set to 0.
# If item has count 1 this value becomes the base for the random chance of it being dropped.
function bki:reset_numbers


function bki:reset_safe
# List of items that always remain after death
# Except for items with the nbt tag always_drop:1b, because this tag have higher priority
# The list formatting must always remain as shown in the example
# "minecraft:<item_name>",\
# It should work with moded items, but ¯\_(ツ)_/¯

# Trigger
scoreboard objectives add check_keep_inventory trigger

say Default values have been set