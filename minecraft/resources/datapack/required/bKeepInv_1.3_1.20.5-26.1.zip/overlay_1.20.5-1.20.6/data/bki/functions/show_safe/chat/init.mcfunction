# Initialising chat construction of safe list

# Print heading
tellraw @s [\
    {"text": "=====================================\
    \nList of items that always remain after death\
    \n=====================================","color": "#F8DE22"},\
    {"text":"\nExcept for items with the nbt tag always_drop:1b, because this tag have higher priority","color":"#03AED2"},\
    {"text": "\nYou can delete an entry by clicking it","color": "#F45B26"},\
    {"text": "\nIt should work with moded items, but ¯\\_(ツ)_/¯","color": "#666251"}]

# Getting the index for numbered list
execute store result score #index levels run data get storage bki:bki safe.list
# Remove 1, because we have to count like programmer, from 0
scoreboard players remove #index levels 1
# Clear last message
data modify storage bki:bki operation.message_list set value []

# Always print something
execute unless data storage bki:bki safe.list[0] run data modify storage bki:bki operation.message_list prepend value {"text":"\\n    List is currently empty.","color":"#F45B26"}

# Make copy of list after as it will be deleted during the recursion and is necessary later
data modify storage bki:bki safe.list_copy set from storage bki:bki safe.list

# Prepare entry for every item
execute if data storage bki:bki safe.list[0] run function bki:show_safe/chat/loop with storage bki:bki operation

# Prints combined message with options
function bki:show_safe/chat/print with storage bki:bki operation

# Safecheck if list was shown
execute unless data storage bki:bki operation.printed run tellraw @s [\
    {"text": "\nIt seems you can't see list of items which should appear above. That mean an item inside it is spelled wrong. If you just added new entry try options below.","color": "#F45B26"},\
    {"text": "\nClick here to remove the last entry","color": "#D12052","underlined": true,"clickEvent": {"action": "suggest_command","value": "/function bki:show_safe/chat/ref_remove {index:'-1'}"}},\
    {"text": "\nor here to ",\
	"color": "#F45B26",\
    "bold": false,\
    "underlined": false\
    },\
    {"text": "Reset to default",\
	"color": "#D12052",\
    "bold": false,\
    "underlined": true,\
	"clickEvent": {\
		"action": "suggest_command",\
		"value": "/function bki:show_safe/chat/ref_reset"\
	}\
}]
# Reset safecheck
data remove storage bki:bki operation.printed