# Constructs entry for one item
$tellraw @s  {\
	"text": "    $(index). $(name)",\
	"color": "#924f18",\
	"bold": false\
}