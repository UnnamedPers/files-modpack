# Constructs entry for one item
$tellraw @s {\
	"text": "    $(index). $(name)",\
	"color": "#924f18",\
	"bold": false,\
	"clickEvent": {\
		"action": "suggest_command",\
		"value": "/function bki:show_safe/chat/ref_remove {index:$(index)}"}\
}