# Prints combined message with options

# $tellraw @s $(message_list)


data modify storage bki:bki operation merge value {printed:1b}