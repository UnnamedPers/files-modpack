# Drop rest of the items

# Get the last element of the list
data modify storage bki:bki drop.item set from storage bki:bki items.after[-1]

# Add some random movement to mimic the orginal
execute store result storage bki:bki drop.x_motion double 0.01 run random value -20..20
execute store result storage bki:bki drop.z_motion double 0.01 run random value -20..20

# Unpack the values
data modify storage bki:bki drop.Slot set from storage bki:bki drop.item.Slot
data modify storage bki:bki drop.type set from storage bki:bki drop.item.type
execute store result storage bki:bki drop.age int 1 run scoreboard players get #age levels

# Check count of the item
execute store result score #item_count levels run data get storage bki:bki drop.item.count 1


execute store result storage bki:bki drop.rchance float 0.01 run scoreboard players get #items_dropped levels
# Depending on whether it is a single or multiple object, apply logic
execute if score #item_count levels matches 1 run function bki:drop/single with storage bki:bki drop
execute if score #item_count levels matches 2.. run function bki:drop/stack

# Remove used element
data remove storage bki:bki items.after[-1]
# repeat till the list is empty
execute if data storage bki:bki items.after[0] run function bki:recursive/drop_rest