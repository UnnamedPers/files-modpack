# Drop and clear the item with random chance, which depends on #items_dropped value (see load or reset function)

$execute if predicate {\
    "condition": "minecraft:random_chance",\
    "chance": $(rchance)\
} run function bki:drop/item with storage bki:bki drop